const getStoredBook = () => {
  const storedReadBook = localStorage.getItem("read-books");
  if (storedReadBook) {
    return JSON.parse(storedReadBook);
  }
  return [];
};

const saveStoredBook = (id) => {
  const storedBook = getStoredBook();
  const exists = storedBook.find((bookId) => bookId === id);
  if (!exists) {
    storedBook.push(id);
    localStorage.setItem("read-books", JSON.stringify(storedBook));
  }
};

export { getStoredBook, saveStoredBook };
