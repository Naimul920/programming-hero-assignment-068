import { useEffect, useState } from "react";
import ReadBook from "../ReadBook/ReadBook";
import WishlistBooks from "../WishlistBooks/WishlistBooks";
import { getStoredBook } from "../../utility/localstorage";
import { useLoaderData } from "react-router-dom";

export default function ListedBooks() {
  const [activeTab, setActiveTab] = useState("Read Books");
  const books = useLoaderData();
  const readBookId = getStoredBook();
  let allReadBooks;
  if (readBookId.length > 0) {
    allReadBooks = books.filter((book) => readBookId.includes(book.bookId));
  }
  return (
    <div>
      <h1 className="bg-slate-400 py-5 rounded-xl mb-10">Book</h1>
      {/* <select className="p-2 mb-5 rounded-lg bg-green-600 border-none outline-none max-w-xs">
        <option disabled selected>
          Sort By
        </option>
        <option>Han Solo</option>
        <option>Greedo</option>
      </select> */}
      <div className="text-left border-b-2 mb-5">
        <button
          className={`tab ${activeTab === "Read Books" && "btn"}`}
          onClick={() => setActiveTab("Read Books")}
        >
          Read Books
        </button>
        <button
          className={`tab ${activeTab === "Wishlist Books" && "btn"}`}
          onClick={() => setActiveTab("Wishlist Books")}
        >
          Wishlist Books
        </button>
      </div>
      <div>
        {activeTab === "Read Books" ? (
          allReadBooks.map((book, index) => (
            <ReadBook key={index} book={book}></ReadBook>
          ))
        ) : (
          <WishlistBooks />
        )}
      </div>
    </div>
  );
}
