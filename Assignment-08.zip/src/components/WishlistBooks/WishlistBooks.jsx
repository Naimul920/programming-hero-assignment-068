export default function WishlistBooks() {
  return (
    <div>
      <h1>WishlistBooks</h1>
    </div>
  )
}
